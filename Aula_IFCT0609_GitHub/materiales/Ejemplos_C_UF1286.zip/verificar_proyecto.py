from pathlib import Path
import subprocess,tempfile,csv,json,sys
ROOT=Path(__file__).parent
src=ROOT/'ejemplos'
bin=ROOT/'bin'
bin.mkdir(exist_ok=True)
results=[]
for p in sorted(src.glob('*.c')):
    if p.name=='medidas.c':continue
    cmd=['gcc','-std=c11','-Wall','-Wextra','-Wpedantic','-Werror',str(p)]
    if p.name=='modular.c':cmd.append(str(src/'medidas.c'))
    cmd+=['-o',str(bin/p.stem)]
    r=subprocess.run(cmd,text=True,capture_output=True)
    assert r.returncode==0,(p.name,r.stderr)
    results.append(p.name)
with tempfile.TemporaryDirectory() as d:
    def run(name,inp=None,args=()):
        return subprocess.run([str((bin/name).resolve()),*args],input=inp,text=True,capture_output=True,cwd=d,timeout=5)
    expected={'01_hola':'Hola, aula','02_variables':'Total: 100.00','03_operadores':'Real: 4.5',
              '05_decisiones':'AVISO','06_while':'5','08_for':'Total: 15','09_main':'Bea, grupo A, nota 8.5',
              '10_funciones':'Resultado: 8','11_porcentaje':'Libre: 10.0 %','12_arrays':'Aprobados: 3',
              '13_punteros':'Cantidad: 4','modular':'15.0','19_memoria':'Primera nota: 5',
              '20_pruebas':'Comprobaciones superadas','17_proceso_posix':'Codigo del hijo: 0'}
    for name,exp in expected.items():
        r=run(name);assert r.returncode==0 and exp in r.stdout,(name,r)
    assert run('04_entrada','4\n').returncode==0
    assert run('04_entrada','hola\n').returncode==1
    assert run('04_entrada','0\n').returncode==1
    assert '7' in run('07_do_while','-1\n7\n').stdout
    for text in ['12\n','100\n','1\n',' 12 \n']:
        assert run('15_conversion',text).returncode==0,text
    for text in ['12abc\n','\n','0\n','999999999999999999999999999999999999999999999999999999999999999999999999\n']:
        assert run('15_conversion',text).returncode==1,text
    assert run('14_escribir').returncode==0
    original=(Path(d)/'nota_demo.txt').read_bytes()
    assert run('14_escribir').returncode==1
    assert (Path(d)/'nota_demo.txt').read_bytes()==original
    assert run('18_registro').returncode==0
    assert run('16_disco_posix').returncode==0
    folder=Path(d)/'datos';folder.mkdir();(folder/'a.txt').write_bytes(b'hola');(folder/'b.txt').write_bytes(b'adios')
    (folder/'sub').mkdir();(folder/'enlace').symlink_to(folder/'a.txt')
    r=run('inventario',args=('datos','informe.csv'));assert r.returncode==0,r.stderr
    assert 'Archivos: 2; bytes: 9' in r.stdout,r.stdout
    report=Path(d)/'informe.csv';old=report.read_bytes()
    with report.open() as f:rows=list(csv.DictReader(f))
    assert {x['nombre']:x['bytes'] for x in rows}=={'a.txt':'4','b.txt':'5'}
    assert run('inventario',args=('datos','informe.csv')).returncode==1
    assert report.read_bytes()==old
    assert run('inventario',args=('datos','datos/dentro.csv')).returncode==1
    assert not (folder/'dentro.csv').exists()
    assert run('inventario',args=('no_existe','otro.csv')).returncode==1
    assert run('inventario',args=('datos/a.txt','otro.csv')).returncode==1
    (Path(d)/'vacia').mkdir()
    assert run('inventario',args=('vacia','vacio.csv')).returncode==0
    for name in ['coma,nombre.txt','nota "final".txt','árbol.txt']:
        (folder/name).write_bytes(b'123')
    r=run('inventario',args=('datos','nombres.csv'));assert r.returncode==0
    with (Path(d)/'nombres.csv').open(encoding='utf8',newline='') as f:rows=list(csv.DictReader(f))
    assert {x['nombre'] for x in rows}=={'a.txt','b.txt','coma,nombre.txt','nota "final".txt','árbol.txt'}
    assert 'Archivos: 5; bytes: 18' in r.stdout
    assert (folder/'a.txt').read_bytes()==b'hola'
    assert (folder/'b.txt').read_bytes()==b'adios'
print(json.dumps({'compiled':len(results),'status':'Todas las comprobaciones superadas','project_cases':['basico','vacio','inexistente','origen archivo','no sobrescritura','destino interno','enlaces','coma y comillas','UTF8','originales conservados']},ensure_ascii=False))
