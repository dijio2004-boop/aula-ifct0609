# Ejemplos en C para UF1286

Edición revisada de noviembre de 2026. Los programas acompañan al manual de C. Las prácticas para entregar no llevan solucionario.

## Primeros pasos

Descomprime el paquete. Entra en la carpeta ejemplos. Cada archivo numerado .c es independiente.

En Linux, por ejemplo:

    gcc -std=c11 -Wall -Wextra -Wpedantic 01_hola.c -o hola
    ./hola

En Windows con GCC configurado, compila con -o hola.exe y ejecuta .\hola.exe desde PowerShell. Los archivos 16_disco_posix.c, 17_proceso_posix.c e inventario.c requieren Linux POSIX, por ejemplo Linux o WSL.

## Ejemplo modular

Los tres archivos medidas.h, medidas.c y modular.c trabajan juntos:

    gcc -std=c11 -Wall -Wextra -Wpedantic modular.c medidas.c -o modular
    ./modular

## Proyecto inventario

    gcc -std=c11 -Wall -Wextra -Wpedantic inventario.c -o inventario

Crea una carpeta nueva de laboratorio, sin archivos personales. Desde la carpeta ejemplos, prepara los datos ficticios:

    mkdir datos_demo
    printf hola > datos_demo/a.txt
    printf adios > datos_demo/b.txt
    mkdir datos_demo/subcarpeta
    ./inventario datos_demo informe_demo.csv

Resultado: 2 archivos, 9 bytes y cero consultas omitidas. El CSV no garantiza orden alfabético. Guarda el informe fuera del origen. Si ya existe, la apertura falla sin sustituirlo. Retorno: 0 completo, 1 fallo, 2 completo con omisiones.

Consulta metadatos, no contenido. Omite subcarpetas y enlaces. No toma una instantánea atómica. Está destinado a un laboratorio controlado. Un fallo de escritura puede dejar un informe parcial, que debes revisar antes de repetir con el mismo nombre.

## Ejemplos que escriben

14_escribir.c crea nota_demo.txt de forma exclusiva y falla si ya existe. 18_registro.c añade una línea a actividad_demo.log. Ejecuta ambos en una carpeta de pruebas.

## Comprobación opcional para el docente

Desde la raíz descomprimida ejecuta:

    python3 verificar_proyecto.py

Esta herramienta auxiliar usa Python 3 y GCC para compilar los programas C, crear datos temporales y comprobar resultados. No es contenido que el alumnado deba programar en Python. Prueba ejemplos, no resuelve las prácticas propuestas. No entrega ejecutables compilados: los crea en bin para el entorno donde se lanza.

## Actualizar el aula web

El PDF revisado mantiene el nombre Manual_programacion_sistemas_UF1286.pdf. Sustitúyelo dentro de Aula_IFCT0609_GitHub/materiales en el repositorio del aula. Ese cambio conserva el enlace actual. El Word y este paquete se pueden añadir como recursos separados si se desea.
