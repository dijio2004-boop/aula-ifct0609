#include <stdio.h>
int main(void) {
    double porcentaje = 10.0;
    if (porcentaje < 5.0) {
        puts("CRITICO");
    } else if (porcentaje < 15.0) {
        puts("AVISO");
    } else {
        puts("OK");
    }
    return 0;
}
