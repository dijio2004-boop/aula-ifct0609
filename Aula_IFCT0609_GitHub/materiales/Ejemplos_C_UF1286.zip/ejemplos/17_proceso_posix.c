#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
int main(void) {
    pid_t hijo = fork();
    if (hijo == -1) { perror("fork"); return 1; }
    if (hijo == 0) {
        execlp("printf", "printf", "%s\n", "5", (char *)NULL);
        perror("exec");
        _exit(127);
    }
    int estado;
    while (waitpid(hijo, &estado, 0) == -1) {
        if (errno != EINTR) { perror("waitpid"); return 1; }
    }
    if (!WIFEXITED(estado)) return 1;
    printf("Codigo del hijo: %d\n", WEXITSTATUS(estado));
    return WEXITSTATUS(estado) == 0 ? 0 : 1;
}
