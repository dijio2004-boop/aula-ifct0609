#include <stdio.h>

int main(void) {
    printf("Hola, aula\n");
    return 0;
}
