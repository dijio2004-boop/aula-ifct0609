#include <assert.h>
#include <math.h>
#include <stdio.h>
double porcentaje(double total, double libre) {
    return libre / total * 100.0;
}
int main(void) {
    assert(fabs(porcentaje(200, 20) - 10.0) < 0.000001);
    assert(fabs(porcentaje(200, 30) - 15.0) < 0.000001);
    puts("Comprobaciones superadas");
    return 0;
}
