#include <stdio.h>
int main(void) {
    int cantidad = 4;
    double precio = 25.0;
    char grupo = 'A';
    char nombre[] = "Ana";
    double total = precio * cantidad;
    printf("%s del grupo %c\n", nombre, grupo);
    printf("Total: %.2f\n", total);
    return 0;
}
