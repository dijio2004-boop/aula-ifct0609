#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <ctype.h>
int main(void) {
    char texto[64], *fin;
    if (fgets(texto, sizeof texto, stdin) == NULL) return 1;
    /* Rechazar lineas que no caben completas. */
    int i = 0;
    while (texto[i] && texto[i] != '\n') i++;
    if (texto[i] != '\n' && !feof(stdin)) {
        fputs("Linea demasiado larga\n", stderr); return 1;
    }
    errno = 0;
    long n = strtol(texto, &fin, 10);
    if (fin == texto || errno == ERANGE) return 1;
    while (isspace((unsigned char)*fin)) fin++;
    if (*fin != '\0' || n < 1 || n > 100) return 1;
    printf("Cantidad: %ld\n", n);
    return 0;
}
