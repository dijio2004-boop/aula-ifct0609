#define _XOPEN_SOURCE 700
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <inttypes.h>

/* Escribe un campo CSV entre comillas y duplica comillas internas. */
static int campo_csv(FILE *salida, const char *texto) {
    if (fputc('"', salida) == EOF) return -1;
    for (const unsigned char *p = (const unsigned char *)texto; *p; p++) {
        if (*p == '"' && fputc('"', salida) == EOF) return -1;
        if (fputc(*p, salida) == EOF) return -1;
    }
    return fputc('"', salida) == EOF ? -1 : 0;
}

/* Rechaza el destino directamente dentro del origen. */
static int destino_externo(const char *origen, const char *destino) {
    char *copia = strdup(destino);
    if (copia == NULL) return 0;
    char *barra = strrchr(copia, '/');
    const char *nombre = barra ? barra + 1 : copia;
    if (*nombre == '\0' || strcmp(nombre, ".") == 0 ||
        strcmp(nombre, "..") == 0) {
        free(copia);
        return 0;
    }
    char *padre;
    if (barra == NULL) {
        padre = realpath(".", NULL);
    } else if (barra == copia) {
        padre = realpath("/", NULL);
    } else {
        *barra = '\0';
        padre = realpath(copia, NULL);
    }
    int valido = padre != NULL && strcmp(origen, padre) != 0;
    free(padre);
    free(copia);
    return valido;
}

static int inventariar(DIR *dir, FILE *salida, uintmax_t *archivos,
                      uintmax_t *bytes, uintmax_t *omitidos) {
    if (fputs("\"nombre\",\"bytes\"\n", salida) == EOF) return -1;
    for (;;) {
        errno = 0;
        struct dirent *entrada = readdir(dir);
        if (entrada == NULL) {
            if (errno != 0) { perror("readdir"); return -1; }
            break;
        }
        if (strcmp(entrada->d_name, ".") == 0 ||
            strcmp(entrada->d_name, "..") == 0) continue;
        struct stat datos;
        if (fstatat(dirfd(dir), entrada->d_name, &datos,
                    AT_SYMLINK_NOFOLLOW) == -1) {
            perror("Consulta omitida");
            if (*omitidos == UINTMAX_MAX) return -1;
            (*omitidos)++;
            continue;
        }
        if (!S_ISREG(datos.st_mode)) continue;
        if (datos.st_size < 0 || *archivos == UINTMAX_MAX ||
            (uintmax_t)datos.st_size > UINTMAX_MAX - *bytes) {
            fputs("Tamano o total fuera de rango\n", stderr);
            return -1;
        }
        if (campo_csv(salida, entrada->d_name) == -1 ||
            fprintf(salida, ",%" PRIuMAX "\n",
                    (uintmax_t)datos.st_size) < 0) return -1;
        (*archivos)++;
        *bytes += (uintmax_t)datos.st_size;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    if (argc != 3) {
        fprintf(stderr, "Uso: %s CARPETA INFORME.csv\n", argv[0]);
        return 1;
    }
    char *origen = realpath(argv[1], NULL);
    if (origen == NULL) { perror("Origen"); return 1; }
    DIR *dir = opendir(origen);
    if (dir == NULL) { perror("Carpeta"); free(origen); return 1; }
    if (!destino_externo(origen, argv[2])) {
        fputs("Destino no valido o dentro del origen\n", stderr);
        closedir(dir); free(origen); return 1;
    }
    free(origen);
    FILE *salida = fopen(argv[2], "wx");
    if (salida == NULL) { perror("Informe"); closedir(dir); return 1; }
    uintmax_t archivos = 0, bytes = 0, omitidos = 0;
    int fallo = inventariar(dir, salida, &archivos, &bytes, &omitidos) == -1;
    if (closedir(dir) == -1) { perror("closedir"); fallo = 1; }
    if (fclose(salida) == EOF) { perror("fclose"); fallo = 1; }
    if (fallo) {
        fputs("Fallo; puede quedar un informe parcial\n", stderr);
        return 1;
    }
    printf("Archivos: %" PRIuMAX "; bytes: %" PRIuMAX "\n", archivos, bytes);
    printf("Consultas omitidas: %" PRIuMAX "\n", omitidos);
    return omitidos ? 2 : 0;
}
