#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <sys/statvfs.h>
int main(void) {
    struct statvfs datos;
    if (statvfs(".", &datos) == -1) {
        perror("statvfs");
        return 1;
    }
    if (datos.f_blocks == 0) return 1;
    double total = (double)datos.f_blocks * datos.f_frsize;
    double disponible = (double)datos.f_bavail * datos.f_frsize;
    double gib = 1024.0 * 1024.0 * 1024.0;
    double porcentaje = disponible / total * 100.0;
    printf("Total: %.2f GiB\n", total / gib);
    printf("Disponible: %.2f GiB\n", disponible / gib);
    printf("Porcentaje disponible: %.1f %%\n", porcentaje);
    return 0;
}
