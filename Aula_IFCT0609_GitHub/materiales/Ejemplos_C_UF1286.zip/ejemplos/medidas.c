#include "medidas.h"
double porcentaje_libre(double total, double libre) {
    return libre / total * 100.0;
}
