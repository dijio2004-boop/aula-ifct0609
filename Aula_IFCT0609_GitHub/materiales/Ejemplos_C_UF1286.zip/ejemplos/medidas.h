#ifndef MEDIDAS_H
#define MEDIDAS_H
double porcentaje_libre(double total, double libre);
#endif
