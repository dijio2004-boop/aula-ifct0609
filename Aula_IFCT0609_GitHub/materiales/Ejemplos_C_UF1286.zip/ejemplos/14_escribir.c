#include <stdio.h>
int main(void) {
    FILE *f = fopen("nota_demo.txt", "wx");
    if (f == NULL) {
        perror("Crear nota_demo.txt");
        return 1;
    }
    int fallo = fprintf(f, "Revision de laboratorio\n") < 0;
    if (fclose(f) == EOF) fallo = 1;
    if (fallo) {
        fputs("No se completo la escritura\n", stderr);
        return 1;
    }
    puts("Archivo creado");
    return 0;
}
