#include <stdio.h>
int main(void) {
    int cantidad;
    printf("Cantidad de equipos entre 1 y 100: ");
    if (scanf("%d", &cantidad) != 1) {
        fprintf(stderr, "Entrada no numerica\n");
        return 1;
    }
    if (cantidad < 1 || cantidad > 100) {
        fprintf(stderr, "Cantidad fuera de rango\n");
        return 1;
    }
    printf("Equipos: %d\n", cantidad);
    return 0;
}
