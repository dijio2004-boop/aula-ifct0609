#include <stdio.h>
#include "medidas.h"
int main(void) {
    printf("%.1f\n", porcentaje_libre(200, 30));
    return 0;
}
