#include <stdio.h>
int main(void) {
    int suma = 0;
    for (int i = 1; i <= 5; i++) {
        suma += i;
        printf("i=%d suma=%d\n", i, suma);
    }
    printf("Total: %d\n", suma);
    return 0;
}
