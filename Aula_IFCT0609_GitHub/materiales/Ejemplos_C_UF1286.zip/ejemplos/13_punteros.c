#include <stdio.h>
void incrementar(int *valor) {
    *valor = *valor + 1;
}
int main(void) {
    int cantidad = 3;
    int *direccion = &cantidad;
    incrementar(direccion);
    printf("Cantidad: %d\n", cantidad);
    return 0;
}
