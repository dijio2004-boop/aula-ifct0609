#include <stdio.h>
int main(void) {
    int nota;
    do {
        printf("Nota entera de 0 a 10: ");
        if (scanf("%d", &nota) != 1) {
            fprintf(stderr, "Entrada no numerica\n");
            return 1;
        }
    } while (nota < 0 || nota > 10);
    printf("Nota aceptada: %d\n", nota);
    return 0;
}
