#include <stdio.h>
int main(void) {
    int a = 9, b = 2;
    double resultado = (double)a / b;
    printf("Entera: %d\n", a / b);
    printf("Real: %.1f\n", resultado);
    printf("Resto: %d\n", a % b);
    return 0;
}
