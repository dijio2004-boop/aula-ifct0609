#include <stdio.h>
double porcentaje_libre(double total, double libre) {
    return libre / total * 100.0;
}
void mostrar_estado(double porcentaje) {
    if (porcentaje < 15.0) {
        puts("AVISO");
    } else {
        puts("OK");
    }
}
int main(void) {
    double total = 200.0, libre = 20.0;
    if (total <= 0 || libre < 0 || libre > total) {
        fputs("Medida invalida\n", stderr);
        return 1;
    }
    double porcentaje = porcentaje_libre(total, libre);
    printf("Libre: %.1f %%\n", porcentaje);
    mostrar_estado(porcentaje);
    return 0;
}
