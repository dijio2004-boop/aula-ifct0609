#include <stdio.h>
#include <time.h>
int main(void) {
    time_t ahora = time(NULL);
    if (ahora == (time_t)-1) return 1;
    struct tm *local = localtime(&ahora);
    char fecha[32];
    if (local == NULL) return 1;
    if (strftime(fecha, sizeof fecha,
                 "%Y-%m-%d %H:%M:%S", local) == 0) return 1;
    FILE *f = fopen("actividad_demo.log", "a");
    if (f == NULL) { perror("registro"); return 1; }
    int fallo = fprintf(f, "%s INFO Inicio de revision\n", fecha) < 0;
    if (fclose(f) == EOF) fallo = 1;
    return fallo ? 1 : 0;
}
