#include <stdio.h>
#include <stdlib.h>
int main(void) {
    size_t cantidad = 4;
    int *notas = malloc(cantidad * sizeof *notas);
    if (notas == NULL) return 1;
    for (size_t i = 0; i < cantidad; i++) notas[i] = 5;
    printf("Primera nota: %d\n", notas[0]);
    free(notas);
    notas = NULL;
    return 0;
}
