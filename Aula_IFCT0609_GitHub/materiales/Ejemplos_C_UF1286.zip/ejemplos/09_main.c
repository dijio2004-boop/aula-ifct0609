#include <stdio.h>
int main(void) {
    char nombre[] = "Bea";
    char grupo = 'A';
    double nota = 8.5;
    printf("%s, grupo %c, nota %.1f\n", nombre, grupo, nota);
    return 0;
}
