#include <stdio.h>
int main(void) {
    int notas[] = {4, 5, 7, 8};
    int suma = 0, aprobados = 0;
    for (int i = 0; i < 4; i++) {
        suma += notas[i];
        if (notas[i] >= 5) aprobados++;
    }
    printf("Media: %.1f\n", suma / 4.0);
    printf("Aprobados: %d\n", aprobados);
    return 0;
}
